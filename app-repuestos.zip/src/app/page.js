import LoginForm from '@/components/login/LoginForm';

export default function HomePage() {
  return (
    <div className='text-2xl font-bold text-red-300'>
      <LoginForm />
    </div>
  );
}
