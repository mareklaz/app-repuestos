import PageHeader from '@/components/PageHeader';

export default function RepairsPage() {
  return (
    <div>
      <PageHeader title='Reparaciones' />
    </div>
  );
}
