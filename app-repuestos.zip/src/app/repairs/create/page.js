export default function CreateRepairPage() {
  return <div>CreateRepairPage</div>;
}
