import PageHeader from '@/components/PageHeader';

export default function DashboardPage() {
  return (
    <div>
      <PageHeader title='Dashboard' />
    </div>
  );
}
