import PageHeader from '@/components/PageHeader';

export default function DevicesPage() {
  return (
    <div>
      <PageHeader title='Dispositivos' />
    </div>
  );
}
