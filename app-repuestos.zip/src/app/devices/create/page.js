export default function CreateDevicePage() {
  return <div>CreateDevicePage</div>;
}
