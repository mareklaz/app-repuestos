import PageHeader from '@/components/PageHeader';

export default function ClientsPage() {
  return (
    <div>
      <PageHeader title='Clientes' />
    </div>
  );
}
