export default function CreateClientPage() {
  return <div>CreateClientPage</div>;
}
